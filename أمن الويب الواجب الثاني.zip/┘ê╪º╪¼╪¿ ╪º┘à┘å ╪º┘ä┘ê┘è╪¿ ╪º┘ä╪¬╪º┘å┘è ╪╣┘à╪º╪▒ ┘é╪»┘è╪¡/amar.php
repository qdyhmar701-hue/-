<?php
$hashedPassword = "";
$result = "";

if (isset($_POST['hash'])) {
    $password = $_POST['password'];
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
}

if (isset($_POST['verify'])) {
    $password = $_POST['password'];
    if (password_verify($password, $hashedPassword)) {
        $result = "Match ";
    } else {
        $result = "No Match ";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Password Hashing</title>
</head>
<body>

<h2>PHP Password Hashing</h2>

<form method="post">
    <input type="password" name="password" placeholder="Enter Password" required>
    <br><br>
    <button type="submit" name="hash">Hash</button>
    <button type="submit" name="verify">Verify</button>
</form>

<?php if ($hashedPassword): ?>
    <p><strong>Hashed Password:</strong> <?= $hashedPassword ?></p>
<?php endif; ?>

<?php if ($result): ?>
    <p><strong>Result:</strong> <?= $result ?></p>
<?php endif; ?>

</body>
</html>
